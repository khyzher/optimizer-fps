package com.bench.fpsopt;

interface IUserService {
    String runCommand(String cmd);
    void destroy();
}
