package com.bench.fpsopt

data class GameProfile(
    val displayName: String,
    val packageName: String,
    val targetFpsHigh: Int,
    val targetFpsLow: Int,
    val densityScale: Int,
    val killBackgroundApps: Boolean,
    val zeroAnimations: Boolean,
    val forcePerformanceMode: Boolean,
    val memFlushLevel: Int
)

object Profiles {

    private const val DENSITY_NORMAL  = 0
    private const val DENSITY_REDUCED = 320
    private const val DENSITY_LIGHT   = 280

    val MCPE_VIBRANT = GameProfile(
        displayName          = "MCPE — Vibrant Visuals",
        packageName          = "com.mojang.minecraftpe",
        targetFpsHigh        = 80,
        targetFpsLow         = 60,
        densityScale         = DENSITY_LIGHT,
        killBackgroundApps   = true,
        zeroAnimations       = true,
        forcePerformanceMode = true,
        memFlushLevel        = 80
    )

    val MCPE_NORMAL = GameProfile(
        displayName          = "MCPE — Standard",
        packageName          = "com.mojang.minecraftpe",
        targetFpsHigh        = 120,
        targetFpsLow         = 90,
        densityScale         = DENSITY_REDUCED,
        killBackgroundApps   = true,
        zeroAnimations       = true,
        forcePerformanceMode = true,
        memFlushLevel        = 80
    )

    val MLBB = GameProfile(
        displayName          = "Mobile Legends: Bang Bang",
        packageName          = "com.mobile.legends",
        targetFpsHigh        = 120,
        targetFpsLow         = 90,
        densityScale         = DENSITY_NORMAL,
        killBackgroundApps   = true,
        zeroAnimations       = true,
        forcePerformanceMode = true,
        memFlushLevel        = 40
    )

    val CODM = GameProfile(
        displayName          = "Call of Duty: Mobile",
        packageName          = "com.activision.callofduty.shooter",
        targetFpsHigh        = 120,
        targetFpsLow         = 90,
        densityScale         = DENSITY_NORMAL,
        killBackgroundApps   = true,
        zeroAnimations       = true,
        forcePerformanceMode = true,
        memFlushLevel        = 40
    )

    val CPM2 = GameProfile(
        displayName          = "Car Parking Multiplayer 2",
        packageName          = "com.olzhassoftware.carparking2",
        targetFpsHigh        = 120,
        targetFpsLow         = 90,
        densityScale         = DENSITY_REDUCED,
        killBackgroundApps   = true,
        zeroAnimations       = true,
        forcePerformanceMode = true,
        memFlushLevel        = 80
    )

    val ROBLOX = GameProfile(
        displayName          = "Roblox",
        packageName          = "com.roblox.client",
        targetFpsHigh        = 120,
        targetFpsLow         = 90,
        densityScale         = DENSITY_REDUCED,
        killBackgroundApps   = true,
        zeroAnimations       = true,
        forcePerformanceMode = true,
        memFlushLevel        = 80
    )

    val ALL = listOf(MCPE_VIBRANT, MCPE_NORMAL, MLBB, CODM, CPM2, ROBLOX)
}
