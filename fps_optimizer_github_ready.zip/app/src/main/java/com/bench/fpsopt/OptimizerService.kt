package com.bench.fpsopt

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

private const val NOTIF_CHANNEL = "fps_opt_ch"
private const val NOTIF_ID      = 1

class OptimizerService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var activeProfile: GameProfile? = null

    companion object {
        const val ACTION_START  = "START_PROFILE"
        const val ACTION_STOP   = "STOP"
        const val EXTRA_PROFILE = "profile_index"
    }

    override fun onCreate() {
        super.onCreate()
        createNotifChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val idx = intent.getIntExtra(EXTRA_PROFILE, 0)
                activeProfile = Profiles.ALL.getOrNull(idx)
                startForeground(NOTIF_ID, buildNotif(activeProfile?.displayName ?: "Active"))
                startLoop()
            }
            ACTION_STOP -> {
                scope.launch { ProfileEngine.reset() }
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startLoop() {
        scope.launch {
            while (isActive) {
                activeProfile?.let { ProfileEngine.apply(it) }
                delay(60_000L) // reapply every 60s — fights thermal governor resets
            }
        }
    }

    private fun createNotifChannel() {
        val ch = NotificationChannel(
            NOTIF_CHANNEL, "FPS Optimizer", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotif(name: String): Notification {
        val stopPI = PendingIntent.getService(
            this, 0,
            Intent(this, OptimizerService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("FPS Optimizer")
            .setContentText("Active: $name")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_media_pause, "Stop", stopPI)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
