package com.bench.fpsopt

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import rikka.shizuku.Shizuku
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

private const val TAG = "ShizukuManager"

object ShizukuManager {

    private var userService: IUserService? = null
    private var connection: ServiceConnection? = null

    val isAvailable: Boolean
        get() = try { Shizuku.pingBinder() } catch (e: Exception) { false }

    val hasPermission: Boolean
        get() = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) { false }

    fun requestPermission(requestCode: Int) = Shizuku.requestPermission(requestCode)

    suspend fun bindService(): Boolean = suspendCoroutine { cont ->
        if (userService != null) { cont.resume(true); return@suspendCoroutine }

        val args = Shizuku.UserServiceArgs(
            ComponentName("com.bench.fpsopt", UserService::class.java.name)
        ).daemon(false).processNameSuffix("service").debuggable(false).version(1)

        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                userService = IUserService.Stub.asInterface(binder)
                connection  = this
                Log.d(TAG, "UserService connected")
                cont.resume(true)
            }
            override fun onServiceDisconnected(name: ComponentName) {
                userService = null
                Log.d(TAG, "UserService disconnected")
            }
        }
        try {
            Shizuku.bindUserService(args, conn)
        } catch (e: Exception) {
            Log.e(TAG, "bind failed: ${e.message}")
            cont.resume(false)
        }
    }

    fun unbindService() {
        connection?.let {
            try {
                Shizuku.unbindUserService(
                    Shizuku.UserServiceArgs(
                        ComponentName("com.bench.fpsopt", UserService::class.java.name)
                    ).daemon(false).processNameSuffix("service").debuggable(false).version(1),
                    it, true
                )
            } catch (_: Exception) {}
        }
        userService = null; connection = null
    }

    fun exec(cmd: String): String {
        val svc = userService ?: return "ERROR: service not bound"
        return try { svc.runCommand(cmd) } catch (e: Exception) { "ERROR: ${e.message}" }
    }
}
