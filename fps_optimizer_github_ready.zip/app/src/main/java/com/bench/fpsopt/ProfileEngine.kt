package com.bench.fpsopt

import android.util.Log

private const val TAG = "ProfileEngine"

object ProfileEngine {

    fun apply(profile: GameProfile): List<String> {
        val log = mutableListOf<String>()

        fun run(cmd: String, label: String): String {
            val r = ShizukuManager.exec(cmd)
            log.add("[$label] $r")
            Log.d(TAG, "[$label] $cmd => $r")
            return r
        }

        // 1. Kill background processes
        if (profile.killBackgroundApps) {
            run("am kill-all", "kill_bg")
            listOf(
                "com.google.android.gms.persistent",
                "com.google.android.gsf",
                "com.android.vending"
            ).forEach { run("am force-stop $it", "force_stop") }
        }

        // 2. Zero animation scales
        if (profile.zeroAnimations) {
            run("settings put global window_animation_scale 0",     "anim_win")
            run("settings put global transition_animation_scale 0", "anim_trans")
            run("settings put global animator_duration_scale 0",    "anim_dur")
        }

        // 3. Disable battery saver + adaptive battery
        run("settings put global low_power 0",                              "bat_saver")
        run("settings put global adaptive_battery_management_enabled 0",    "adaptive_bat")
        run("settings put global app_standby_enabled 0",                    "standby")

        // 4. Sustained performance / performance mode
        if (profile.forcePerformanceMode) {
            run("am broadcast -a com.android.server.action.UPDATE_POWER_PROFILE --es profile PERFORMANCE",
                "power_perf")
            run("device_config put activity_manager_native_boot sys.background_boost_boost 1",
                "bg_boost")
            run("am broadcast -a com.mediatek.power.BOOST --ei duration 0",
                "mtk_boost")
            run("am broadcast -a com.mediatek.power.PERF_BOOST --ei mode 1 --ei duration 300000",
                "mtk_perf")
        }

        // 5. Memory flush
        if (profile.memFlushLevel > 0) {
            run("am send-trim-memory ${profile.packageName} ${profile.memFlushLevel}",
                "mem_flush")
        }

        // 6. Refresh rate lock
        val fps = profile.targetFpsHigh
        run("settings put system peak_refresh_rate $fps.0",  "peak_rr")
        run("settings put system min_refresh_rate $fps.0",   "min_rr")
        run("device_config put display_manager refresh_rate_in_zone $fps", "rr_zone")
        run("device_config put display_manager display_refresh_rate_zone_threshold_lux 0",
            "rr_lux")
        run("service call SurfaceFlinger 1035 i32 0 i32 2",  "sf_power")

        // 7. Density override (reduces GPU load)
        if (profile.densityScale > 0) {
            run("wm density ${profile.densityScale}", "wm_density")
            log.add("[density_note] Reset density after gaming: wm density reset")
        }

        // 8. WiFi low-latency
        run("cmd wifi force-high-perf-mode enabled",   "wifi_perf")
        run("cmd wifi force-low-latency-mode enabled", "wifi_latency")

        // 9. Launch game
        run("monkey -p ${profile.packageName} -c android.intent.category.LAUNCHER 1",
            "launch")

        return log
    }

    fun reset(): List<String> {
        val log = mutableListOf<String>()
        fun run(cmd: String, label: String) { log.add("[$label] ${ShizukuManager.exec(cmd)}") }
        run("wm density reset",                                     "density_reset")
        run("settings put global window_animation_scale 1",        "anim_win")
        run("settings put global transition_animation_scale 1",    "anim_trans")
        run("settings put global animator_duration_scale 1",       "anim_dur")
        run("settings put system peak_refresh_rate 120.0",         "rr_reset")
        run("settings put system min_refresh_rate 60.0",           "min_rr_reset")
        run("cmd wifi force-high-perf-mode disabled",              "wifi_perf_off")
        run("cmd wifi force-low-latency-mode disabled",            "wifi_lat_off")
        return log
    }
}
